<?php
// =============================================
// login.php — БИЛЕТ 3 «Фитнес58»
// Логин администратора: Admin
// Пароль администратора: fitness58   ← ОТЛИЧАЕТСЯ ОТ БИЛЕТОВ 1 И 2!
// =============================================
include_once "./session.php";
include_once "./db.php";

if (is_authorized()) {
    header("Location: index.php");
    exit();
}

$user_not_found = false;
$password_incorrect = false;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // ИЗМЕНИТЬ: если таблица пользователей называется иначе — поменяй 'users'
    // ИЗМЕНИТЬ: если поле логина называется иначе — поменяй 'username'
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = $mysqli->query($query);

    if ($result->num_rows == 0) {
        $user_not_found = true;
    } else {
        $user = $result->fetch_assoc();

        // ИЗМЕНИТЬ: если поле пароля в БД называется иначе — поменяй 'password'
        if ($password != $user['password']) {
            $password_incorrect = true;
        } else {
            // ИЗМЕНИТЬ: если поле роли в БД называется иначе — поменяй 'role_id'
            authorize($user['id'], $user['role_id']);

            // role_id = 1 → личный кабинет
            // role_id = 2 (и любое другое) → панель администратора
            if (get_session_user_role() == 1) {
                header("Location: account.php");
            } else {
                header("Location: admin.php");
            }
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация — Фитнес58</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body>
    <?php include "./nav.php"; ?>

    <!-- По ТЗ: заголовок страницы -->
    <h1>Авторизация</h1>

    <form id="login-form" method="post">

        <label for="username">Имя пользователя</label>
        <input type="text" name="username" id="username" required placeholder="Имя пользователя">

        <!-- Сообщение об ошибке: пользователь не найден -->
        <?php if ($user_not_found): ?>
            <p style="color: red;">Пользователь не найден</p>
        <?php endif; ?>

        <label for="password">Пароль</label>
        <input type="password" name="password" id="password" required placeholder="Пароль">

        <!-- Сообщение об ошибке: неверный пароль -->
        <?php if ($password_incorrect): ?>
            <p style="color: red;">Неправильный пароль</p>
        <?php endif; ?>

        <button type="submit">Войти</button>

        <!-- По ТЗ: ссылка на страницу регистрации -->
        <a href="register.php">Нет аккаунта? Зарегистрироваться</a>
    </form>
</body>
</html>
