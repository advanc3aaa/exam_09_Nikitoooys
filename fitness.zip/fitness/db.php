<?php
// Изменено под fitness58_portal.sql: подключение к актуальной БД экзамена.
$mysqli = new mysqli("127.0.0.1", "root", "", "fitness58_portal");
$mysqli->set_charset("utf8mb4");
