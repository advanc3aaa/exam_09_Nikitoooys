<?php
include_once "./session.php";
include_once "./db.php";

if (!is_authorized()) {
    header("Location: login.php");
    exit();
}

if (get_session_user_role() != 1) {
    header("Location: admin.php");
    exit();
}

$user_id = (int) get_session_user_id();
$res = $mysqli->query("SELECT * FROM users WHERE id='$user_id'");
$current_user = $res->fetch_assoc();

$query = "SELECT * FROM requests WHERE user_id='$user_id' ORDER BY desired_date, id";
$result = $mysqli->query($query);
$requests = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Изменено под fitness58_portal.sql: в таблице statuses используются id 1..3.
$statuses = [
    1 => "Запланировано",
    2 => "Посещено",
    3 => "Отменено"
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет - Фитнес58</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body>
    <?php include "nav.php"; ?>

    <h1>Личный кабинет</h1>
    <p>Добро пожаловать, <strong><?= htmlspecialchars($current_user['firstname']) ?> <?= htmlspecialchars($current_user['lastname']) ?></strong>!</p>

    <table border="1" cellpadding="8" cellspacing="0">
        <thead>
            <tr>
                <th>Вид тренировки</th>
                <th>Желаемая дата посещения</th>
                <th>Время тренировки</th>
                <th>Статус заявки</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requests as $request): ?>
            <tr>
                <td><?= htmlspecialchars($request['training_type']) ?></td>
                <td><?= htmlspecialchars($request['desired_date']) ?></td>
                <td><?= htmlspecialchars($request['training_time']) ?></td>
                <td><?= htmlspecialchars($statuses[$request['status_id']] ?? 'Неизвестно') ?></td>
            </tr>
            <?php endforeach; ?>

            <?php if (empty($requests)): ?>
            <tr>
                <td colspan="4">У вас пока нет заявок на тренировки</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="add.php">+ Записаться на тренировку</a>
</body>
</html>
