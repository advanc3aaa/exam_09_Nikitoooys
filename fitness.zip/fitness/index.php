<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ИЗМЕНИТЬ: название портала по билету 3 -->
    <title>Фитнес58</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body>
    <?php include "./nav.php"; ?>
    <!-- По ТЗ: каждая страница должна содержать заголовок -->
    <h1>Портал «Фитнес58»</h1>
    <p>Система записи на тренировки в спортзал</p>
</body>
</html>
