<?php
include_once "./session.php";
include_once "./db.php";

if (!is_authorized() || get_session_user_role() == 1) {
    http_response_code(403);
    echo "forbidden";
    exit();
}

$request_id = (int) ($_POST['request_id'] ?? 0);
$status = (int) ($_POST['status'] ?? 0);

// Изменено под fitness58_portal.sql: колонка статуса называется status_id.
$query = "UPDATE requests SET status_id='$status' WHERE id='$request_id'";
$mysqli->query($query);

echo "ok";
