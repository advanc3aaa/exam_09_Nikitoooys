<?php
include_once './session.php';
include_once './db.php';

if (!is_authorized()) {
    header("Location: login.php");
    exit();
}

if (get_session_user_role() != 1) {
    header("Location: admin.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $user_id = (int) get_session_user_id();
    $training_type = $mysqli->real_escape_string($_POST['training_type']);
    $visit_date = $mysqli->real_escape_string($_POST['visit_date']);
    $visit_time = $mysqli->real_escape_string($_POST['visit_time']);

    // Изменено под fitness58_portal.sql: реальные поля requests -> desired_date, training_time, status_id.
    $query = "
        INSERT INTO requests (user_id, training_type, desired_date, training_time, status_id)
        VALUES ('$user_id', '$training_type', '$visit_date', '$visit_time', '1')
    ";
    $mysqli->query($query);

    header("Location: account.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новая заявка - Фитнес58</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body>
    <?php include "./nav.php"; ?>

    <h1>Запись на тренировку</h1>

    <form id="add-form" method="post">
        <label for="training_type">Вид тренировки</label>
        <select name="training_type" id="training_type" required>
            <option value="">- Выберите вид тренировки -</option>
            <option value="Групповое занятие">Групповое занятие</option>
            <option value="Тренажерный зал">Тренажерный зал</option>
            <option value="Бассейн">Бассейн</option>
            <option value="Единоборства">Единоборства</option>
        </select>

        <label for="visit_date">Желаемая дата посещения</label>
        <input type="date" name="visit_date" id="visit_date" required>

        <label>Время тренировки</label>
        <div>
            <input type="radio" name="visit_time" value="Утро" id="morning" required>
            <label for="morning">Утро</label>
        </div>
        <div>
            <input type="radio" name="visit_time" value="День" id="afternoon">
            <label for="afternoon">День</label>
        </div>
        <div>
            <input type="radio" name="visit_time" value="Вечер" id="evening">
            <label for="evening">Вечер</label>
        </div>

        <button type="submit">Записаться</button>
        <a href="account.php">Вернуться в личный кабинет</a>
    </form>
</body>
</html>
