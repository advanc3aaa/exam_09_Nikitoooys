<?php
// =============================================
// nav.php — БИЛЕТ 3 «Фитнес58»
// =============================================
include_once "./session.php";
?>
<nav>
    <?php if (is_authorized()): ?>
        <!-- Кнопка выхода — для любой роли -->
        <a href="logout.php">Выход</a>

        <?php if (get_session_user_role() == 1): ?>
            <!-- role_id = 1 → обычный пользователь (посетитель спортзала) -->
            <a href="account.php">Личный кабинет</a>
            <!-- ИЗМЕНИТЬ: в билете 3 это "Новая заявка" на тренировку -->
            <a href="add.php">Новая заявка</a>
        <?php else: ?>
            <!-- role_id = 2 → администратор -->
            <a href="admin.php">Панель администратора</a>
        <?php endif; ?>

    <?php else: ?>
        <!-- Не авторизован -->
        <a href="register.php">Регистрация</a>
        <a href="login.php">Авторизация</a>
    <?php endif; ?>
</nav>
