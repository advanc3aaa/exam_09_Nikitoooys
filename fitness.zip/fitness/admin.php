<?php
include_once "./session.php";
include_once "./db.php";

if (!is_authorized()) {
    header("Location: login.php");
    exit();
}

if (get_session_user_role() == 1) {
    header("Location: account.php");
    exit();
}

$query = "
    SELECT requests.*, requests.id AS request_id,
           users.firstname, users.middlename, users.lastname
    FROM requests
    JOIN users ON requests.user_id = users.id
    ORDER BY requests.desired_date, requests.id
";
$result = $mysqli->query($query);
$requests = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Изменено под fitness58_portal.sql: в таблице statuses используются id 1..3.
$statuses = [
    1 => "Запланировано",
    2 => "Посещено",
    3 => "Отменено"
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - Фитнес58</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body class="admin-page">
    <?php include "./nav.php"; ?>

    <h1>Панель администратора</h1>

    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ФИО пользователя</th>
                    <th>Вид тренировки</th>
                    <th>Желаемая дата посещения</th>
                    <th>Время тренировки</th>
                    <th>Текущий статус</th>
                    <th>Изменить статус</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?= htmlspecialchars($request['lastname'] . ' ' . $request['firstname'] . ' ' . $request['middlename']) ?></td>
                    <td><?= htmlspecialchars($request['training_type']) ?></td>
                    <td><?= htmlspecialchars($request['desired_date']) ?></td>
                    <td><?= htmlspecialchars($request['training_time']) ?></td>
                    <td><?= htmlspecialchars($statuses[$request['status_id']] ?? 'Неизвестно') ?></td>
                    <td class="status-cell">
                        <select id="status_<?= $request['request_id'] ?>">
                            <option value="1" <?= $request['status_id'] == 1 ? 'selected' : '' ?>>Запланировано</option>
                            <option value="2" <?= $request['status_id'] == 2 ? 'selected' : '' ?>>Посещено</option>
                            <option value="3" <?= $request['status_id'] == 3 ? 'selected' : '' ?>>Отменено</option>
                        </select>
                        <button type="button" onclick="updateStatus(<?= $request['request_id'] ?>)">Сохранить</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
    function updateStatus(id) {
        const status = document.getElementById('status_' + id).value;
        fetch('update_status.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'request_id=' + id + '&status=' + status
        })
        .then(response => response.text())
        .then(data => {
            if (data === 'ok') {
                alert('Статус успешно обновлен');
                location.reload();
            } else {
                alert('Ошибка при обновлении статуса');
            }
        });
    }
    </script>
</body>
</html>
