<?php
include_once "./session.php";
include_once "./db.php";

if (!is_authorized()) {
    header("Location: login.php");
    exit();
}

if (get_session_user_role() != 1) {
    header("Location: admin.php");
    exit();
}

$user_id = (int) get_session_user_id();
$res = $mysqli->query("SELECT * FROM users WHERE id='$user_id'");
$current_user = $res->fetch_assoc();

// Изменено под clinic_appointments_2.sql: статус хранится в status_id, врач в Vrach, дата/время в date/time.
$query = "SELECT * FROM requests WHERE user_id='$user_id' ORDER BY date, time";
$result = $mysqli->query($query);
$requests = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

$statuses = [
    1 => "Новая заявка",
    2 => "Услуга оказана",
    3 => "Услуга отменена"
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет - Запись в поликлинику</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body>
    <?php include "nav.php"; ?>

    <h1>Личный кабинет</h1>
    <p>Добро пожаловать, <strong><?= htmlspecialchars($current_user['firstname']) ?> <?= htmlspecialchars($current_user['lastname']) ?></strong>!</p>

    <table border="1" cellpadding="8" cellspacing="0">
        <thead>
            <tr>
                <th>Врач</th>
                <th>Желаемая дата приема</th>
                <th>Время приема</th>
                <th>Статус записи</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requests as $request): ?>
            <tr>
                <td><?= htmlspecialchars($request['Vrach']) ?></td>
                <td><?= htmlspecialchars($request['date']) ?></td>
                <td><?= htmlspecialchars(substr($request['time'], 0, 5)) ?></td>
                <td><?= htmlspecialchars($statuses[$request['status_id']] ?? 'Неизвестно') ?></td>
            </tr>
            <?php endforeach; ?>

            <?php if (empty($requests)): ?>
            <tr>
                <td colspan="4">У вас пока нет записей</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="add.php">+ Записаться к врачу</a>
</body>
</html>
