<?php
// =============================================
// session.php — УНИВЕРСАЛЬНЫЙ для всех билетов
// Трогать ничего не нужно
// =============================================
session_start();

function authorize($id, $role_id)
{
    $_SESSION['authorized'] = true;
    $_SESSION['id'] = $id;
    $_SESSION['role_id'] = $role_id;
}

function unauthorize()
{
    $_SESSION['authorized'] = false;
    $_SESSION['id'] = 0;
    $_SESSION['role_id'] = 0;
}

function is_authorized()
{
    if (isset($_SESSION['authorized'])) {
        return $_SESSION['authorized'];
    } else {
        return false;
    }
}

function get_session_user_id()
{
    if (isset($_SESSION['id'])) {
        return $_SESSION['id'];
    } else {
        return false;
    }
}

function get_session_user_role()
{
    if (isset($_SESSION['role_id'])) {
        return $_SESSION['role_id'];
    } else {
        return false;
    }
}
