<?php
include_once './session.php';
include_once './db.php';

if (!is_authorized()) {
    header("Location: login.php");
    exit();
}

if (get_session_user_role() != 1) {
    header("Location: admin.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $user_id = (int) get_session_user_id();

    // Изменено под clinic_appointments_2.sql: реальные поля requests -> Vrach, date, time, status_id.
    $doctor = $mysqli->real_escape_string($_POST['doctor']);
    $visit_date = $mysqli->real_escape_string($_POST['visit_date']);
    $visit_time = $mysqli->real_escape_string($_POST['visit_time']);

    $query = "
        INSERT INTO requests (user_id, Vrach, date, time, status_id)
        VALUES ('$user_id', '$doctor', '$visit_date', '$visit_time', '1')
    ";
    $mysqli->query($query);

    header("Location: account.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новая запись - Запись в поликлинику</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body>
    <?php include "./nav.php"; ?>

    <h1>Запись к врачу</h1>

    <form id="add-form" method="post">
        <!-- Изменено под clinic_appointments_2.sql: варианты врачей совпадают с дампом БД. -->
        <label for="doctor">Врач</label>
        <select name="doctor" id="doctor" required>
            <option value="">- Выберите врача -</option>
            <option value="Иванов В.Е.">Иванов В.Е.</option>
            <option value="Григорьев В.А.">Григорьев В.А.</option>
            <option value="Горева А.А">Горева А.А</option>
            <option value="Иннина А.В">Иннина А.В</option>
        </select>

        <label for="visit_date">Желаемая дата приема</label>
        <input type="date" name="visit_date" id="visit_date" required>

        <!-- Изменено под clinic_appointments_2.sql: в БД хранится точное время, поэтому используем input type="time". -->
        <label for="visit_time">Время приема</label>
        <input type="time" name="visit_time" id="visit_time" required>

        <button type="submit">Записаться</button>
        <a href="account.php">Вернуться в личный кабинет</a>
    </form>
</body>
</html>
