<?php
include_once './session.php';
include_once './db.php';

if (is_authorized()) {
    header("Location: index.php");
    exit();
}

$user_exist = false;
$password_mismatch = false;
$phone_incorrect = false;
$date_incorrect = false;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $firstname = trim($_POST['firstname']);
    $middlename = trim($_POST['middlename']);
    $lastname = trim($_POST['lastname']);
    $birthdate = trim($_POST['birthdate']);
    $phone = trim($_POST['phone']);

    $username_sql = $mysqli->real_escape_string($username);
    $result = $mysqli->query("SELECT username FROM users WHERE username = '$username_sql'");

    if ($result && $result->num_rows > 0) {
        $user_exist = true;
    } elseif ($password != $password2) {
        $password_mismatch = true;
    } elseif (!preg_match('/^\d{10}$|^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/', $phone)) {
        // Изменено под clinic_appointments_2.sql: принимаем 10 цифр из дампа и формат 8(XXX)XXX-XX-XX.
        $phone_incorrect = true;
    } elseif (!preg_match('/^\d{2}\.\d{2}\.\d{4}$/', $birthdate)) {
        $date_incorrect = true;
    } else {
        // Изменено под clinic_appointments_2.sql: users содержит поля phone и D_R.
        $birthdate_parts = explode('.', $birthdate);
        $birthdate_sql = $birthdate_parts[2] . '-' . $birthdate_parts[1] . '-' . $birthdate_parts[0];
        $phone_sql = preg_replace('/\D/', '', $phone);
        if (strlen($phone_sql) === 11 && $phone_sql[0] === '8') {
            $phone_sql = substr($phone_sql, 1);
        }

        $firstname_sql = $mysqli->real_escape_string($firstname);
        $middlename_sql = $mysqli->real_escape_string($middlename);
        $lastname_sql = $mysqli->real_escape_string($lastname);
        $password_sql = $mysqli->real_escape_string($password);

        $query = "
            INSERT INTO users (username, password, firstname, middlename, lastname, phone, D_R, role_id)
            VALUES ('$username_sql', '$password_sql', '$firstname_sql', '$middlename_sql', '$lastname_sql', '$phone_sql', '$birthdate_sql', '1')
        ";
        $mysqli->query($query);
        header("Location: login.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Запись в поликлинику</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body>
    <?php include "./nav.php"; ?>

    <h1>Регистрация</h1>

    <form id="register-form" method="post">
        <label for="username">Логин</label>
        <input type="text" name="username" id="username" required minlength="6" pattern="[A-Za-z0-9]+" placeholder="Логин">
        <?php if ($user_exist): ?>
            <p style="color: red;">Пользователь с таким именем уже существует</p>
        <?php endif; ?>

        <label for="password">Пароль</label>
        <input type="password" name="password" id="password" required minlength="8" placeholder="Пароль">

        <label for="password2">Подтверждение пароля</label>
        <input type="password" name="password2" id="password2" required minlength="8" placeholder="Повторите пароль">
        <?php if ($password_mismatch): ?>
            <p style="color: red;">Пароли не совпадают</p>
        <?php endif; ?>

        <label for="lastname">Фамилия</label>
        <input type="text" name="lastname" id="lastname" required placeholder="Фамилия">

        <label for="firstname">Имя</label>
        <input type="text" name="firstname" id="firstname" required placeholder="Имя">

        <label for="middlename">Отчество</label>
        <input type="text" name="middlename" id="middlename" required placeholder="Отчество">

        <label for="birthdate">Дата рождения</label>
        <input type="text" name="birthdate" id="birthdate" required placeholder="ДД.ММ.ГГГГ">
        <?php if ($date_incorrect): ?>
            <p style="color: red;">Неверный формат даты. Пример: 15.08.1990</p>
        <?php endif; ?>

        <label for="phone">Телефон</label>
        <input type="text" name="phone" id="phone" required placeholder="8(XXX)XXX-XX-XX или 10 цифр">
        <?php if ($phone_incorrect): ?>
            <p style="color: red;">Неверный формат телефона</p>
        <?php endif; ?>

        <button type="submit">Зарегистрироваться</button>
        <a href="login.php">Уже есть аккаунт? Войти</a>
    </form>
</body>
</html>
