<?php
include_once "./session.php";
include_once "./db.php";

if (!is_authorized()) {
    header("Location: login.php");
    exit();
}

if (get_session_user_role() == 1) {
    header("Location: account.php");
    exit();
}

$query = "
    SELECT requests.*, requests.id AS request_id,
           users.firstname, users.middlename, users.lastname
    FROM requests
    JOIN users ON requests.user_id = users.id
    ORDER BY requests.date, requests.time
";
$result = $mysqli->query($query);
$requests = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Изменено под clinic_appointments_2.sql: в таблице statuses используются id 1..3.
$statuses = [
    1 => "Новая заявка",
    2 => "Услуга оказана",
    3 => "Услуга отменена"
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - Запись в поликлинику</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
    <style>
        /* Запасной вариант: границы видны даже если внешний CSS кэшируется. */
        body.admin-page {
            max-width: 1400px !important;
            margin: 0 auto !important;
            width: 100% !important;
        }

        .table-wrap {
            width: 100% !important;
            margin: 0 auto !important;
            overflow-x: auto !important;
            text-align: center !important;
        }

        body.admin-page nav {
            width: 100% !important;
            max-width: 500px !important;
            align-self: center !important;
            margin: 0 auto 20px auto !important;
        }

        body.admin-page h1 {
            width: fit-content !important;
            min-width: 980px !important;
            margin: 0 auto 16px auto !important;
            text-align: left !important;
        }

        .admin-table {
            border-collapse: collapse !important;
            border: 2px solid #6b7280 !important;
            margin: 0 auto !important;
            display: inline-table !important;
        }

        .admin-table th,
        .admin-table td {
            border: 1px solid #6b7280 !important;
            white-space: nowrap !important;
        }

        .status-cell {
            min-width: 220px !important;
            text-align: center !important;
        }

        .status-cell select {
            width: 160px !important;
            margin-bottom: 8px !important;
            margin-left: auto !important;
            margin-right: auto !important;
            display: block !important;
        }

        .status-cell button {
            width: 160px !important;
            display: block !important;
            margin-left: auto !important;
            margin-right: auto !important;
        }
    </style>
</head>
<body class="admin-page">
    <?php include "./nav.php"; ?>

    <h1>Панель администратора</h1>

    <div class="table-wrap">
        <table class="admin-table" border="1" cellspacing="0" cellpadding="8">
            <thead>
                <tr>
                    <th>ФИО пациента</th>
                    <th>Врач</th>
                    <th>Желаемая дата приема</th>
                    <th>Время приема</th>
                    <th>Текущий статус</th>
                    <th>Изменить статус</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?= htmlspecialchars($request['lastname'] . ' ' . $request['firstname'] . ' ' . $request['middlename']) ?></td>
                    <td><?= htmlspecialchars($request['Vrach']) ?></td>
                    <td><?= htmlspecialchars($request['date']) ?></td>
                    <td><?= htmlspecialchars(substr($request['time'], 0, 5)) ?></td>
                    <td><?= htmlspecialchars($statuses[$request['status_id']] ?? 'Неизвестно') ?></td>
                    <td class="status-cell">
                        <select id="status_<?= $request['request_id'] ?>">
                            <option value="1" <?= $request['status_id'] == 1 ? 'selected' : '' ?>>Новая заявка</option>
                            <option value="2" <?= $request['status_id'] == 2 ? 'selected' : '' ?>>Услуга оказана</option>
                            <option value="3" <?= $request['status_id'] == 3 ? 'selected' : '' ?>>Услуга отменена</option>
                        </select>
                        <button type="button" onclick="updateStatus(<?= $request['request_id'] ?>)">Сохранить</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
    function updateStatus(id) {
        const status = document.getElementById('status_' + id).value;
        fetch('update_status.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'request_id=' + id + '&status=' + status
        })
        .then(response => response.text())
        .then(data => {
            if (data === 'ok') {
                alert('Статус успешно обновлен');
                location.reload();
            } else {
                alert('Ошибка при обновлении статуса');
            }
        });
    }
    </script>
</body>
</html>
