<?php
// =============================================
// logout.php — УНИВЕРСАЛЬНЫЙ для всех билетов
// =============================================
include_once "./session.php";
unauthorize();
header("Location: login.php");
exit();
