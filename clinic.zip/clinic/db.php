<?php
// Изменено под clinic_appointments_2.sql: подключение к актуальной БД экзамена.
$mysqli = new mysqli("127.0.0.1", "root", "", "clinic_appointments");
$mysqli->set_charset("utf8mb4");
