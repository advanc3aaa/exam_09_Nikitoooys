<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ИЗМЕНИТЬ: название портала по билету 2 -->
    <title>Запись в поликлинику</title>
    <link rel="stylesheet" href="styles.css?v=20260411">
</head>
<body>
    <?php include "./nav.php"; ?>
    <!-- По ТЗ: каждая страница должна содержать заголовок -->
    <h1>Портал «Запись в поликлинику»</h1>
    <p>Система записи пациентов на приём к врачам</p>
</body>
</html>
